# The Billionaire Android wrapper

This is an Android Studio project that packages the online game in a native Android WebView.

Before release, change the URL in `MainActivity.java` to the actual Railway production URL.
Open the `android` folder in Android Studio, sync Gradle, then Build > Build APK(s).
